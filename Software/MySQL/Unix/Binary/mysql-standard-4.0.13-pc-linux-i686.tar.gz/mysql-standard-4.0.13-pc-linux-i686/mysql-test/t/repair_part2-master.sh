echo "1" > $MYSQL_TEST_DIR/var/master-data/test/t1.MYI
