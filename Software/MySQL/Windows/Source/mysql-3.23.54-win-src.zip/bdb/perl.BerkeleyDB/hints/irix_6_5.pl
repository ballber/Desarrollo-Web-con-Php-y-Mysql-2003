$self->{LIBS} = [ "@{$self->{LIBS}} -lthread" ];
