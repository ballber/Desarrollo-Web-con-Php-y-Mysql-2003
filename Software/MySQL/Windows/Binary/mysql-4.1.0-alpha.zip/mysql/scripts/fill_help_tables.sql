USE mysql;
DROP TABLE IF EXISTS help_topic;
CREATE TABLE help_topic (  help_topic_id int unsigned not null auto_increment,  name          varchar(64) not null,  description   text not null,  example       text not null,  url           varchar(128) not null,  primary key   (help_topic_id),  unique index(name)) type=myisam;

DROP TABLE IF EXISTS help_category;
CREATE TABLE help_category (  help_category_id smallint unsigned not null auto_increment,  name             varchar(64) not null,  url              varchar(128) not null,  primary key      (help_category_id),  unique index (name)) type=myisam;

DROP TABLE IF EXISTS help_relation;
CREATE TABLE help_relation (   help_topic_id    int unsigned not null references help_topic,   help_category_id smallint unsigned not null references help_category,   primary key      (help_category_id, help_topic_id),) type=myisam;

SET @cur_category=null;

DELETE help_category FROM help_category LEFT JOIN help_relation ON help_category.help_category_id=help_relation.help_category_id WHERE help_relation.help_category_id is null;
