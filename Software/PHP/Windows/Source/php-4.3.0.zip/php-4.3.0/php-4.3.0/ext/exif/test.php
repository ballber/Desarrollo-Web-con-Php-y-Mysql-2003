<?php
	include 'test.txt';
?>