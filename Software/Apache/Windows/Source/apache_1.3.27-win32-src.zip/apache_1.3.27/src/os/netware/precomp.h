#pragma precompile_target "precomp.mch"
#define NETWARE

#ifndef __int64
#define __int64 long long
#endif





