<?php include('header.php'); ?>
<FORM ACTION="search.php" METHOD=POST>
<INPUT NAME="keyword" SIZE=20>
<INPUT TYPE=SUBMIT VALUE="Search">
</FORM>
<?php include('footer.php'); ?>
