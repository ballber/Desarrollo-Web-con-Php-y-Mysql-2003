<TITLE>SuperFastOnlineNews</TITLE>
<TABLE BORDER=0 HEIGHT=100% WIDTH=100% CELLSPACING=0>
<TR>
  <TD BGCOLOR="orange" COLSPAN=2 HEIGHT=10 WIDTH=100%>&nbsp;</TD>
</TR>
<TR>
  <TD VALIGN=TOP HEIGHT=100% BGCOLOR="orange">
    <IMG SRC="logo.gif" WIDTH=100 HEIGHT=50>
    <br />
    <FONT FACE="arial, sans-serif" SIZE=2>
    <A HREF="headlines.php">Headlines</A>
    <br />
    <br />
    <A HREF="page.php?page=news">News</A>
    <br />
    <A HREF="page.php?page=sport">Sport</A>
    <br />
    <A HREF="page.php?page=weather">Weather</A>
    </FONT>
  </TD>
  <TD VALIGN=TOP WIDTH=100%>
    <FONT FACE="arial, sans-serif">
    <H1>SuperFastOnlineNews</H1>
