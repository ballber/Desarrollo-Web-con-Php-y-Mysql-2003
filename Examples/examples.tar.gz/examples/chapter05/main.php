<?php
  echo "This is the main file.<br />";
  require( "reusable.php" );
  echo "The script will end now.<br />";
?>

