<?php
  // putting all the include files here means 
  // that it will take time to load each one 
  // for every page, but that we wil not 
  // forget any

  include_once('db_fns.php');
  include_once('user_auth_fns.php');
  include_once('select_fns.php');

  session_start();
?>
